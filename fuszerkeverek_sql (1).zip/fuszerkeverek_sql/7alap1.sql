SELECT nev
FROM keverek
WHERE …;
