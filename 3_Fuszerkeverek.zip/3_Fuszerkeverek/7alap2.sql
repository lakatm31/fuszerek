SELECT keverek.nev
FROM osszetevo, keverek, kapcsolat
WHERE keverek.id = keverekid AND osszetevo.id = osszetevoid AND
…;
